---
name: proxmox-cluster-infrastructure
description: "Build, configure, and verify Proxmox VE / Proxmox Datacenter Manager infrastructure: PVE API login, LXC provisioning, PDM setup, LLDAP access, remote cluster registration, no-subscription repo setup, and subscription-nag mitigation."
---

# Proxmox Cluster Infrastructure

Use this skill when asked to administer a Proxmox VE cluster, deploy Proxmox Datacenter Manager (PDM), add PVE nodes/remotes to PDM, configure LDAP/LLDAP access, or fix PDM post-install UI/repository issues.

## Safety and boundaries

- Treat Proxmox/PDM credentials, API tickets, CSRF tokens, generated API tokens, LDAP bind passwords, and root passwords as sensitive. Do **not** print them in final responses or save them in skills/memory.
- Prefer API verification over GUI assumptions. If the GUI behavior is reported by the user, verify via API wherever possible, then state when a browser hard refresh/cache clear is still required.
- When using community scripts, inspect the current raw script first and apply only the needed sections when running interactively is impractical.
- For destructive operations (destroying CTs/VMs, replacing remotes, modifying ACLs), verify the target node/VMID/remote ID first and avoid affecting unrelated workloads.

## Proxmox VE API login pattern

1. Discover the authentication realm before assuming username format:
   - `GET /api2/json/access/domains`
   - Common working form for LLDAP-backed users is `username@LLDAP-Domain`.
2. Authenticate:
   - `POST /api2/json/access/ticket` with `username` and `password`.
   - Store `PVEAuthCookie` in the session and send `CSRFPreventionToken` for POST/PUT/DELETE.
3. Verify access with read-only endpoints:
   - `GET /api2/json/version`
   - `GET /api2/json/nodes`
   - `GET /api2/json/access/permissions`
4. Redact ticket and CSRF values in logs/summaries.

## PDM deployment / LXC provisioning pattern

- Community script reference: `https://community-scripts.org/scripts/proxmox-datacenter-manager`.
- Raw script location used by the site may be `https://raw.githubusercontent.com/community-scripts/ProxmoxVE/main/ct/proxmox-datacenter-manager.sh`.
- The script creates a Debian LXC and installs PDM packages from the PDM no-subscription repository.
- If direct host shell is unavailable, Proxmox API can still create a CT:
  1. Upload or select an LXC template from node storage.
  2. `POST /nodes/{node}/lxc` with CT settings.
  3. Poll `/nodes/{tasknode}/tasks/{UPID}/status` until `stopped` and `exitstatus=OK`.
  4. Start and verify `https://<ct-ip>:8443/`.
- Non-root Proxmox API users may be blocked from certain LXC features. Example: `keyctl=1` requires `root@pam`; use `features=nesting=1` unless root-level PVE access is available.

## PDM root/PAM password management

- PDM root user is `root@pam` in the API and typically `root` + realm `pam` in the GUI.
- Password can be changed with:
  - `PUT /api2/json/access/users/root%40pam` and form field `password=<new password>`.
- Verify immediately:
  - new password authenticates to `POST /api2/json/access/ticket`;
  - old password fails.

## LLDAP setup in PDM

1. Configure realm files or API according to the current PDM version.
2. Verify realm visibility:
   - `GET /api2/json/access/domains` should show `LLDAP-Domain`.
3. Trigger sync:
   - `POST /api2/json/access/domains/LLDAP-Domain/sync`.
   - Poll `/nodes/{pdm-node}/tasks/{UPID}/status` and inspect log for `TASK OK`.
4. Confirm users and ACLs:
   - `GET /api2/json/access/users`
   - `GET /api2/json/access/acl`
   - `GET /api2/json/access/permissions` while logged in as an LLDAP user.

### Pitfall: users can authenticate but see no dashboard/settings

This usually means PDM has authentication working but ACL/resource permissions are missing or not visible to that user. Check:

- user exists after realm sync;
- ACL entries grant `Administrator` or `Auditor` at `/` with propagation;
- user-specific `GET /access/permissions` includes expected paths such as `/`, `/access`, `/resource`, `/system`;
- at least one PDM remote exists and resources are visible via `/resources/status` and `/resources/list`.

## Adding Proxmox VE remotes to PDM

1. Discover target node list from the source of truth (spreadsheet, inventory, or PVE cluster API).
2. Use `POST /pve/probe-tls` against an entry node to obtain the certificate fingerprint when needed.
3. Use `POST /pve/scan` with `hostname`, trusted `fingerprint`, `authid`, and token/password field expected by the current API to discover the remote cluster node list and fingerprints.
4. Add the remote with:
   - `POST /remotes/remote`
   - JSON fields: `id`, `type: "pve"`, `nodes`, `authid`, `token`, optional `web-url`, optional `create-token`.
5. If `create-token` is provided, PDM will generate and store a remote API token; final API listings redact the token value.
6. Verify:
   - `GET /remotes/remote`
   - `GET /remotes/remote/{id}/version`
   - `GET /resources/status`
   - `GET /resources/list`

## Removing stale/offline PVE cluster nodes

Use when the Proxmox GUI shows offline nodes that will not be reused, often with errors like `hostname lookup '<node>' failed`.

1. Verify the cluster is quorate before any removal:
   - `GET /api2/json/cluster/status`
   - or host shell: `pvecm status`
2. Confirm targets are offline/stale and contain no guest configs:
   - API: `GET /api2/json/nodes` and `GET /api2/json/cluster/resources?type=node`
   - Host shell: `find /etc/pve/nodes/<node> -maxdepth 3 -type f | sort`
   - Safe stale dirs usually contain only files such as `lrm_status`, `pve-ssl.key`, `pve-ssl.pem`, `ssh_known_hosts`; investigate before deletion if `qemu-server/*.conf` or `lxc/*.conf` exists.
3. From a healthy online cluster node, run for each stale node:
   - `pvecm delnode <node-name>`
   - It may print `Could not kill node (error = CS_ERR_NOT_EXIST)` for already-offline nodes; this can be acceptable if the corosync config version increments and the node disappears from `pvecm nodes` / API.
4. Verify after removal:
   - `pvecm status` shows `Expected votes` equal to the remaining online node count.
   - `pvecm nodes` no longer lists the targets.
   - `GET /api2/json/nodes` and `GET /api2/json/cluster/resources?type=node` no longer include the targets.
   - If PDM monitors the cluster, `GET /api2/json/resources/status` on PDM should show `pve_nodes.offline: 0` and remote status `Good`.

## PVE host shell via API console

If SSH is unavailable but the Proxmox API user has console permission, use `/nodes/{node}/termproxy` + `/nodes/{node}/vncwebsocket` to open the node console, send the `user:ticket` line first, then log in on the console. This is useful for root-only cluster maintenance commands such as `pvecm delnode`.

## PDM subscription popup / post-install no-subscription handling

Use when the GUI shows “No valid subscriptions” or asks to visit `pdm.proxmox.com`.

- Community script page: `https://community-scripts.org/scripts/post-pdm-install`.
- Current raw script path observed: `https://raw.githubusercontent.com/community-scripts/ProxmoxVE/main/tools/pve/post-pdm-install.sh`.
- The relevant nag-removal logic appends a `PDM_NO_MORE_NAGGING` JavaScript block to:
  - `/usr/share/javascript/proxmox-datacenter-manager/js/pdm-ui_bundle.js`
- It also installs a persistence hook:
  - `/usr/local/bin/pdm-remove-nag.sh`
  - `/etc/apt/apt.conf.d/no-nag-script`
- Always back up the JS bundle before patching.
- Restart `proxmox-datacenter-api.service` after patching.
- Verify `/js/pdm-ui_bundle.js` contains `PDM_NO_MORE_NAGGING`, `MutationObserver`, `pdm.proxmox.com`, and `d.close()`.
- Tell the user to hard-refresh the browser (`Ctrl+Shift+R`) because the old bundle may be cached.

See `references/pdm-deployment-and-postinstall.md` for the concrete session recipe and API endpoints used.